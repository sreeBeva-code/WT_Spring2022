<?php
include("../model/model.php");
if(isset($_POST["submit"]))
{
    $fname=$_POST["fname"];
    $lname=$_POST["lname"];
    $age=$_POST["age"];
    $salary=$_POST["salary"];
if(empty($fname)||empty($lname)||empty($age)||empty($salary))
{
    echo"Please insert all field";
}
else
{
$mydb=new DB();
$connobj=$mydb->opencon();
$mydb->InsertData($fname,$lname,$age,$salary,"person",$connobj);
$mydb->closecon($connobj);
}


}

?>