<?php
include("../control/registrationcheck.php");
?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>from</title>
    </head>
    <body>
        <form>
        
      
       
        
            <table>
       <tr>
        <td>Name :</td>
        <td><input type="text" name="first_name"></td>
       </tr>
        <tr>
        <td>Last name :</td>
        <td><input type="text" name="last_name"></td>
       </tr>
       <tr>
        <td>Age :</td>
        <td><input type="number" name="age"></td>
       </tr>
       <tr>
        <td>Designation :</td>
        <td>
         <input type="radio" name="de"> junior programmer
         <input type="radio" name="de"> senior programmer
         <input type="radio" name="de"> project lead

        </td>
       </tr>
       <tr>
        <td>Designation :</td>
        <td>
         <input type="checkbox" name="skill"> JAVA
         <input type="checkbox" name="skill"> PHP
         <input type="checkbox" name="skill"> c++

        </td>
       </tr>
       <tr>
        <td>Email :</td>
        <td><input type="email" name="email"></td>
       </tr>
        <tr>
        <td>Password :</td>
        <td><input type="Password" name="Password"></td>
       </tr>
       <tr>
        <td>Please choose a file :</td>
        <td><input type="file" name="file"></td>
       </tr>

       
       <tr>
        <td><input type="submit" value="Submit"></td>
       </tr>
       <tr>
        <td><input type="reset" value="reset"></td>
       </tr>
      
     
            

        </form>
        
            
            







        

    </body>
    </html>
